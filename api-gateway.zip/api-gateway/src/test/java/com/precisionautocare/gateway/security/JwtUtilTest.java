package com.precisionautocare.gateway.security;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

class JwtUtilTest {

    private static final String SECRET = "PrecisionAutoCareSecretKeyForJwtTokenGeneration123456";
    private JwtUtil jwtUtil;
    private SecretKey key;

    @BeforeEach
    void setUp() {
        jwtUtil = new JwtUtil(SECRET);
        key = Keys.hmacShaKeyFor(SECRET.getBytes(StandardCharsets.UTF_8));
    }

    private String createTestToken(String subject, String role, long expirationOffsetMs) {
        return Jwts.builder()
                .subject(subject)
                .claim("role", role)
                .issuedAt(new Date())
                .expiration(new Date(System.currentTimeMillis() + expirationOffsetMs))
                .signWith(key)
                .compact();
    }

    @Test
    void testValidToken() {
        String token = createTestToken("alice", "ADMIN", 3600000);
        assertTrue(jwtUtil.isTokenValid(token));
        assertEquals("alice", jwtUtil.extractUsername(token));
        assertEquals("ADMIN", jwtUtil.extractRole(token));
    }

    @Test
    void testInvalidToken() {
        assertFalse(jwtUtil.isTokenValid("gibberish-token"));
        assertNull(jwtUtil.extractUsername("gibberish-token"));
        assertNull(jwtUtil.extractRole("gibberish-token"));
    }

    @Test
    void testExpiredToken() {
        String expiredToken = createTestToken("bob", "USER", -5000);
        assertFalse(jwtUtil.isTokenValid(expiredToken));
    }
}
