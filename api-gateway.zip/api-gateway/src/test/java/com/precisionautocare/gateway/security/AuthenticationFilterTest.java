package com.precisionautocare.gateway.security;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.mock.web.server.MockServerWebExchange;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.concurrent.atomic.AtomicBoolean;

import static org.junit.jupiter.api.Assertions.*;

class AuthenticationFilterTest {

    private static final String SECRET = "PrecisionAutoCareSecretKeyForJwtTokenGeneration123456";
    private AuthenticationFilter authenticationFilter;
    private SecretKey key;

    @BeforeEach
    void setUp() {
        JwtUtil jwtUtil = new JwtUtil(SECRET);
        authenticationFilter = new AuthenticationFilter(jwtUtil);
        key = Keys.hmacShaKeyFor(SECRET.getBytes(StandardCharsets.UTF_8));
    }

    private String createTestToken(String subject, String role, long expirationOffsetMs) {
        return Jwts.builder()
                .subject(subject)
                .claim("role", role)
                .issuedAt(new Date())
                .expiration(new Date(System.currentTimeMillis() + expirationOffsetMs))
                .signWith(key)
                .compact();
    }

    @Test
    void testOpenEndpointAllowsWithoutToken() {
        MockServerHttpRequest request = MockServerHttpRequest.post("/api/auth/login").build();
        MockServerWebExchange exchange = MockServerWebExchange.from(request);

        AtomicBoolean chainInvoked = new AtomicBoolean(false);
        GatewayFilterChain chain = ex -> {
            chainInvoked.set(true);
            return Mono.empty();
        };

        authenticationFilter.filter(exchange, chain).block();

        assertTrue(chainInvoked.get(), "Chain should be invoked for open endpoint");
        assertNull(exchange.getResponse().getStatusCode());
    }

    @Test
    void testSecuredEndpointMissingTokenReturns401() {
        MockServerHttpRequest request = MockServerHttpRequest.get("/api/bookings").build();
        MockServerWebExchange exchange = MockServerWebExchange.from(request);

        AtomicBoolean chainInvoked = new AtomicBoolean(false);
        GatewayFilterChain chain = ex -> {
            chainInvoked.set(true);
            return Mono.empty();
        };

        authenticationFilter.filter(exchange, chain).block();

        assertFalse(chainInvoked.get(), "Chain should not be invoked when token is missing");
        assertEquals(HttpStatus.UNAUTHORIZED, exchange.getResponse().getStatusCode());
    }

    @Test
    void testSecuredEndpointMalformedHeaderReturns401() {
        MockServerHttpRequest request = MockServerHttpRequest.get("/api/bookings")
                .header(HttpHeaders.AUTHORIZATION, "Basic 12345")
                .build();
        MockServerWebExchange exchange = MockServerWebExchange.from(request);

        AtomicBoolean chainInvoked = new AtomicBoolean(false);
        GatewayFilterChain chain = ex -> {
            chainInvoked.set(true);
            return Mono.empty();
        };

        authenticationFilter.filter(exchange, chain).block();

        assertFalse(chainInvoked.get());
        assertEquals(HttpStatus.UNAUTHORIZED, exchange.getResponse().getStatusCode());
    }

    @Test
    void testSecuredEndpointInvalidTokenReturns401() {
        MockServerHttpRequest request = MockServerHttpRequest.get("/api/bookings")
                .header(HttpHeaders.AUTHORIZATION, "Bearer invalid.token.value")
                .build();
        MockServerWebExchange exchange = MockServerWebExchange.from(request);

        AtomicBoolean chainInvoked = new AtomicBoolean(false);
        GatewayFilterChain chain = ex -> {
            chainInvoked.set(true);
            return Mono.empty();
        };

        authenticationFilter.filter(exchange, chain).block();

        assertFalse(chainInvoked.get());
        assertEquals(HttpStatus.UNAUTHORIZED, exchange.getResponse().getStatusCode());
    }

    @Test
    void testSecuredEndpointExpiredTokenReturns401() {
        String expiredToken = createTestToken("alice", "USER", -10000);
        MockServerHttpRequest request = MockServerHttpRequest.get("/api/bookings")
                .header(HttpHeaders.AUTHORIZATION, "Bearer " + expiredToken)
                .build();
        MockServerWebExchange exchange = MockServerWebExchange.from(request);

        AtomicBoolean chainInvoked = new AtomicBoolean(false);
        GatewayFilterChain chain = ex -> {
            chainInvoked.set(true);
            return Mono.empty();
        };

        authenticationFilter.filter(exchange, chain).block();

        assertFalse(chainInvoked.get());
        assertEquals(HttpStatus.UNAUTHORIZED, exchange.getResponse().getStatusCode());
    }

    @Test
    void testSecuredEndpointValidTokenMutatesHeadersAndProceeds() {
        String validToken = createTestToken("charlie", "MANAGER", 3600000);
        MockServerHttpRequest request = MockServerHttpRequest.get("/api/bookings")
                .header(HttpHeaders.AUTHORIZATION, "Bearer " + validToken)
                .build();
        MockServerWebExchange exchange = MockServerWebExchange.from(request);

        AtomicBoolean chainInvoked = new AtomicBoolean(false);
        GatewayFilterChain chain = (ServerWebExchange ex) -> {
            chainInvoked.set(true);
            assertEquals("charlie", ex.getRequest().getHeaders().getFirst("X-Auth-User"));
            assertEquals("MANAGER", ex.getRequest().getHeaders().getFirst("X-Auth-Role"));
            return Mono.empty();
        };

        authenticationFilter.filter(exchange, chain).block();

        assertTrue(chainInvoked.get(), "Chain should be invoked with mutated headers");
    }
}
